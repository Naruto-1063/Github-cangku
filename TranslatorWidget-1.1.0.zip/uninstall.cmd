@cd /d "%TEMP%" && powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1" %* || (echo. & pause)
