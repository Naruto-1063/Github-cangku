# 翻译挂件（Windows 10）

一个常驻桌面的小型中英翻译挂件：支持划词翻译、截图/图片 OCR 翻译、可配置全局快捷键、窗口缩放和本地语音朗读。

## 功能

- 无边框圆角小窗，可拖动、可调整大小、可隐藏到系统托盘
- 窗口置顶可开启/取消，默认置顶，重启后保留
- 选中文字后按 `Ctrl+Alt+T`，自动读取选中内容、翻译并在鼠标旁显示
- 按 `Ctrl+Alt+S` 截取屏幕区域，或点击“图片翻译”选择图片；本地 OCR 识别后再翻译
- `Ctrl+Alt+W` 显示/隐藏窗口
- “自动” / “中 → 英” / “英 → 中”三种方向
- 设置窗口可以修改划词、截图、显隐三组全局快捷键
- 设置窗口可以开关“根据文本或图片自动调整窗口大小”
- 可用鼠标拖动窗口边缘或右下角手柄缩放；开启自动适应后，翻译文本或图片会按内容调整高度/宽度
- 译文可复制
- 原文和译文均可语音朗读，使用 Windows 本地语音
- 关闭窗口只是隐藏，托盘菜单中才真正退出

## 系统要求

- Windows 10 64 位
- .NET Framework 4.8（Windows 10 1903 及以上通常自带）
- 需要联网使用 Google 在线翻译
- 截图/图片 OCR 使用 Windows 自带的 `Windows.Media.Ocr`，本机需要安装简体中文 OCR 语言包
  - 当前系统只有 `zh-Hans-CN` 识别语言，中文 OCR 可同时识别常见拉丁字母
- 语音使用 Windows SAPI，默认需要中文和英文语音；本机已安装
  - 中文：Microsoft Huihui Desktop
  - 英文：Microsoft Zira Desktop

## 安装

1. 双击 `install.cmd`
2. 安装程序默认安装到：

   ```text
   F:\自制插件、软件\翻译挂件
   ```

3. 安装完成后会自动启动，并在桌面和开始菜单创建“翻译挂件”快捷方式
4. 安装不需要管理员权限；不会修改系统级设置

如果希望安装到其他目录：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -InstallDir "D:\工具\翻译挂件"
```

如果希望开机启动：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Startup
```

默认不添加开机启动。

## 使用

- 启动后窗口默认在屏幕右下角，并保持置顶
- 在任意程序里选中要翻译的文字，按 `Ctrl+Alt+T`
- 程序优先通过 Windows UI Automation 读取选中文本；不支持 UIA 的程序再回退到模拟 `Ctrl+C`
- 回退取词时会先备份剪贴板，取词完成后恢复原样；没有选中文本时只提示，不会拿旧剪贴板内容翻译
- 按 `Ctrl+Alt+S` 或点击“截图翻译”，在全屏遮罩上拖选区域；按 `Esc` 取消
- 点击“图片翻译”选择本地图片；识别后的文字显示在原文框，并自动翻译
- 图片预览显示在窗口底部，可点“移除”清理；OCR 图片只在本机处理
- 顶部“置顶”按钮可立即切换窗口置顶状态；按钮显示“已置顶”表示当前置顶
- 拖动窗口边缘或右下角手柄可调整大小；设置里可关闭自动适应
- 设置窗口可修改三组全局快捷键，并恢复默认快捷键/默认窗口大小
- 关闭或最小化窗口会隐藏到托盘；右键托盘图标可以显示/隐藏、切换置顶、截图翻译、打开设置或退出
- 输入框内按 `Ctrl+Enter` 翻译，按 `Esc` 隐藏窗口
- 热键注册失败时，界面会提示失败，不会静默改用其他组合键；请在设置中更换

## 在线翻译与隐私

- 翻译使用 Google 的免密钥公开接口，不需要配置 API Key
- 待翻译的文本会发送到 Google 的服务器；请勿用它翻译不希望外发的敏感内容
- 截图和图片 OCR 完全在本机通过 Windows OCR 完成，图片不会上传
- OCR 识别出的文字仍会发送到 Google 翻译
- 截图临时文件在图片被移除、重新截图或程序退出时删除
- 接口不是正式商业 API，可能出现限流、无法连接或协议变化

## 语音

- 使用 Windows 本地 SAPI 语音，不会把朗读文本发送到网络
- 原文“朗读”使用原文语言对应的语音，译文“朗读”使用译文语言对应的语音
- 当前系统中英文语音都可用；如果系统未安装对应语言语音，会回退到默认语音

## 设置与日志

- 设置文件：

  ```text
  %APPDATA%\TranslatorWidget\settings.json
  ```

- 错误日志：

  ```text
  %APPDATA%\TranslatorWidget\error.log
  ```

- 设置包括置顶状态、翻译方向、窗口位置、窗口大小、自动适应开关和三组全局快捷键
- 卸载时默认保留设置；如要一并清理：

  ```powershell
  powershell -NoProfile -ExecutionPolicy Bypass -File .\uninstall.ps1 -RemoveSettings
  ```

## 卸载

双击安装目录中的 `uninstall.cmd`（或使用发行包中的 `uninstall.cmd`），会：

- 关闭正在运行的翻译挂件
- 删除桌面、开始菜单和开机启动快捷方式
- 删除 `F:\自制插件、软件\翻译挂件` 安装目录
- 默认保留 `%APPDATA%\TranslatorWidget` 设置

不会删除 `F:\自制插件、软件` 中的其他内容。

## 常见问题

**按热键没有反应**

- 确认程序正在运行（查看系统托盘）
- 打开设置，检查对应快捷键是否被其他软件占用；保存时若注册失败会保留原设置并提示
- 可以按当前的“显示/隐藏”快捷键呼出窗口，检查状态

**无法取到选中文本**

- 目标程序以管理员身份运行时，普通权限的挂件无法读取或模拟复制；可尝试以管理员身份运行挂件
- 某些 UWP/游戏/远程桌面程序不支持 UIA 或模拟 `Ctrl+C`
- 选中内容不是文本（例如图片）时不会翻译，请改用截图/图片翻译

**截图或图片没有识别出文字**

- 确认 Windows 已安装简体中文 OCR 语言包
- 尽量截取清晰、对比度高的文字区域
- 当前 OCR 只支持简体中文模型，无法识别其他语言包中的文字

**翻译失败**

- 检查网络和代理；程序使用系统代理
- Google 接口在部分地区可能不可访问，或短时间被限流
- 程序会自动尝试备用 Google 接口，仍失败时会显示中文错误提示

**朗读没有声音**

- 检查系统音量、默认输出设备
- 检查 Windows 是否安装中英文语音
- 错误信息会显示在窗口底部

**Windows 提示未知发布者**

- 程序由本机使用系统自带编译器构建，没有购买代码签名证书；SmartScreen 可能提示，属于正常现象

## 便携使用

解压 `TranslatorWidget-1.1.0.zip` 后，可直接双击 `TranslatorWidget.exe` 运行，不创建快捷方式。设置仍保存在 `%APPDATA%\TranslatorWidget`。

## 从源码构建

需要 Windows 10 64 位和系统自带的 .NET Framework 4.8 编译器。无需 .NET SDK、Node.js 或 Python。

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```

输出：

```text
dist\TranslatorWidget.exe
dist\TranslatorWidget-1.1.0.zip
```

运行自动化检查：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\tests\SmokeTest.ps1
```
