﻿[CmdletBinding()]
param(
    [string]$InstallDir = 'F:\自制插件、软件\翻译挂件',
    [switch]$Startup,
    [switch]$NoShortcuts,
    [switch]$NoLaunch
)

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$appName = '翻译挂件'
$version = '1.1.0'

function Fail([string]$message) {
    Write-Host "安装失败: $message" -ForegroundColor Red
    exit 1
}

$exeSource = Join-Path $scriptDir 'TranslatorWidget.exe'
if (-not (Test-Path -LiteralPath $exeSource)) {
    $portableSource = Join-Path $scriptDir 'dist\TranslatorWidget.exe'
    if (Test-Path -LiteralPath $portableSource) {
        $exeSource = $portableSource
    }
    else {
        Fail "找不到 TranslatorWidget.exe。请把 install.cmd 和 exe 放在同一目录。"
    }
}

$targetDir = [System.IO.Path]::GetFullPath($InstallDir).TrimEnd('\')
$parentDir = [System.IO.Path]::GetFullPath('F:\自制插件、软件').TrimEnd('\')
if ($targetDir -eq $parentDir) {
    Fail "不要把程序直接安装到 F:\自制插件、软件 根目录，请使用子目录。"
}
$driveRoot = [System.IO.Path]::GetPathRoot($targetDir)
if (-not (Test-Path -LiteralPath $driveRoot)) {
    Fail "目标磁盘不存在: $driveRoot"
}

Write-Host '========================================'
Write-Host "  $appName 安装程序"
Write-Host '========================================'
Write-Host "安装目录: $targetDir"

try {
    New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
}
catch {
    Fail "无法创建安装目录：$($_.Exception.Message)"
}

$targetExe = Join-Path $targetDir 'TranslatorWidget.exe'

Get-Process -Name 'TranslatorWidget' -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        if ($_.Path -eq $targetExe) {
            Stop-Process -Id $_.Id -Force
        }
    }
    catch {
    }
}
Start-Sleep -Milliseconds 300

try {
    Copy-Item -LiteralPath $exeSource -Destination $targetExe -Force
    foreach ($fileName in @('uninstall.cmd', 'uninstall.ps1', 'README.md')) {
        $source = Join-Path $scriptDir $fileName
        if (Test-Path -LiteralPath $source) {
            Copy-Item -LiteralPath $source -Destination (Join-Path $targetDir $fileName) -Force
        }
    }
}
catch {
    Fail "复制程序文件失败：$($_.Exception.Message)"
}

$marker = [ordered]@{
    Product = 'TranslatorWidget'
    Name = $appName
    Version = $version
    InstallDir = $targetDir
    InstalledAt = (Get-Date).ToString('o')
}
$marker | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $targetDir 'install.json') -Encoding UTF8

function New-Shortcut([string]$shortcutPath) {
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $targetExe
    $shortcut.WorkingDirectory = $targetDir
    $shortcut.IconLocation = "$targetExe,0"
    $shortcut.Description = "$appName - Windows 10 中英划词翻译"
    $shortcut.Save()
}

if (-not $NoShortcuts) {
    try {
        $desktopLink = Join-Path ([Environment]::GetFolderPath('Desktop')) "$appName.lnk"
        New-Shortcut $desktopLink
        Write-Host "已创建桌面快捷方式: $desktopLink"

        $programsLink = Join-Path ([Environment]::GetFolderPath('Programs')) "$appName.lnk"
        New-Shortcut $programsLink
        Write-Host "已创建开始菜单快捷方式: $programsLink"

        if ($Startup) {
            $startupLink = Join-Path ([Environment]::GetFolderPath('Startup')) "$appName.lnk"
            New-Shortcut $startupLink
            Write-Host "已添加开机启动: $startupLink"
        }
    }
    catch {
        Write-Host "创建快捷方式失败，但程序已复制到安装目录：$($_.Exception.Message)" -ForegroundColor Yellow
    }
}

Write-Host ''
Write-Host '安装完成。' -ForegroundColor Green
Write-Host "程序位置: $targetExe"
Write-Host '快捷键: Ctrl+Alt+T 划词翻译，Ctrl+Alt+S 截图翻译，Ctrl+Alt+W 显示/隐藏'
Write-Host "设置文件: $env:APPDATA\TranslatorWidget\settings.json"
Write-Host ''

if (-not $NoLaunch) {
    Start-Process -FilePath $targetExe -WorkingDirectory $targetDir
}
