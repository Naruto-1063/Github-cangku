﻿[CmdletBinding()]
param(
    [string]$InstallDir = 'F:\自制插件、软件\翻译挂件',
    [switch]$RemoveSettings,
    [switch]$Delayed
)

$ErrorActionPreference = 'Stop'
$appName = '翻译挂件'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $PSBoundParameters.ContainsKey('InstallDir') -and
    (Test-Path -LiteralPath (Join-Path $scriptDir 'install.json'))) {
    $InstallDir = $scriptDir
}
$targetDir = [System.IO.Path]::GetFullPath($InstallDir).TrimEnd('\')
$parentDir = [System.IO.Path]::GetFullPath('F:\自制插件、软件').TrimEnd('\')
$scriptDirFull = [System.IO.Path]::GetFullPath($scriptDir).TrimEnd('\')

# 从安装目录内启动时，先把卸载脚本复制到临时目录并交给独立进程，
# 避免 cmd/PowerShell 正在读取的脚本被自身删除而导致退出错误。
if (-not $Delayed -and $scriptDirFull -eq $targetDir) {
    $tempScript = Join-Path $env:TEMP ('TranslatorWidget-uninstall-' + [Guid]::NewGuid().ToString('N') + '.ps1')
    Copy-Item -LiteralPath (Join-Path $scriptDir 'uninstall.ps1') -Destination $tempScript -Force
    $arguments = @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', ('"' + $tempScript + '"'),
        '-InstallDir', ('"' + $targetDir + '"'),
        '-Delayed'
    )
    if ($RemoveSettings) {
        $arguments += '-RemoveSettings'
    }
    Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -WindowStyle Hidden
    Write-Host '卸载程序已启动，正在清理安装目录…'
    exit 0
}

if ($Delayed) {
    Start-Sleep -Milliseconds 1200
}

function Remove-ShortcutIfMatches([string]$shortcutPath, [string]$targetExe) {
    if (-not (Test-Path -LiteralPath $shortcutPath)) {
        return
    }
    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        if ([System.IO.Path]::GetFullPath($shortcut.TargetPath) -eq $targetExe) {
            Remove-Item -LiteralPath $shortcutPath -Force
            Write-Host "已删除快捷方式: $shortcutPath"
        }
    }
    catch {
    }
}

if ($targetDir -eq $parentDir -or $targetDir -eq [System.IO.Path]::GetPathRoot($targetDir).TrimEnd('\')) {
    Write-Host '拒绝卸载：目标目录层级不安全。' -ForegroundColor Red
    exit 1
}

$targetExe = Join-Path $targetDir 'TranslatorWidget.exe'
$marker = Join-Path $targetDir 'install.json'

if (-not (Test-Path -LiteralPath $marker) -and -not (Test-Path -LiteralPath $targetExe)) {
    Write-Host "没有找到 $appName 的安装记录：$targetDir" -ForegroundColor Yellow
    exit 1
}

Get-Process -Name 'TranslatorWidget' -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        if ($_.Path -eq $targetExe) {
            Stop-Process -Id $_.Id -Force
        }
    }
    catch {
    }
}
Start-Sleep -Milliseconds 300

Remove-ShortcutIfMatches (Join-Path ([Environment]::GetFolderPath('Desktop')) "$appName.lnk") $targetExe
Remove-ShortcutIfMatches (Join-Path ([Environment]::GetFolderPath('Programs')) "$appName.lnk") $targetExe
Remove-ShortcutIfMatches (Join-Path ([Environment]::GetFolderPath('Startup')) "$appName.lnk") $targetExe

if (Test-Path -LiteralPath $targetDir) {
    try {
        Remove-Item -LiteralPath $targetDir -Recurse -Force
        Write-Host "已删除安装目录: $targetDir"
    }
    catch {
        Write-Host "删除安装目录失败：$($_.Exception.Message)" -ForegroundColor Red
        Write-Host '请关闭程序后重试。'
        exit 1
    }
}

if ($RemoveSettings) {
    $settingsDir = Join-Path $env:APPDATA 'TranslatorWidget'
    if (Test-Path -LiteralPath $settingsDir) {
        Remove-Item -LiteralPath $settingsDir -Recurse -Force
        Write-Host "已删除设置: $settingsDir"
    }
}
else {
    Write-Host "已保留设置: $env:APPDATA\TranslatorWidget"
}

Write-Host "$appName 已卸载。" -ForegroundColor Green
